//Provide the implementation for the LinkedList class in this file.

