//Provide the implementation for the Stack class in this file.

