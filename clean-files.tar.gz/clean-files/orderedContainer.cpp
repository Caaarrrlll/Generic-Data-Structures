// Implement non-pure virtual functions of OrderedContainer here
